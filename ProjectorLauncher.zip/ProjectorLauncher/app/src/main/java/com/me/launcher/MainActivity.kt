package com.me.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Collections

class Entry(val ri: ResolveInfo, val pkg: String, val hidden: Boolean)

class MainActivity : Activity() {

    private lateinit var root: View
    private lateinit var favTitle: View
    private lateinit var favRow: RecyclerView
    private lateinit var allRow: RecyclerView
    private lateinit var prefs: SharedPreferences

    private val favAdapter = AppAdapter(230, true)
    private val allAdapter = AppAdapter(170, false)

    private var pins = mutableListOf<String>()
    private var order = mutableListOf<String>()
    private var hidden = mutableSetOf<String>()
    private var restList = listOf<String>()
    private var showHidden = false
    private var theme = 1
    private var pendingFocus: String? = null

    private val themes = arrayOf(
        intArrayOf(0xFF0B1020.toInt(), 0xFF1B2440.toInt(), 0xFF3A2A5C.toInt()),
        intArrayOf(0xFF12000C.toInt(), 0xFF7A1038.toInt(), 0xFF3B1E6E.toInt()),
        intArrayOf(0xFF001F2E.toInt(), 0xFF004E64.toInt(), 0xFF0B7A75.toInt()),
        intArrayOf(0xFF000000.toInt(), 0xFF111111.toInt(), 0xFF262626.toInt())
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("launcher", MODE_PRIVATE)
        setContentView(R.layout.activity_main)
        root = findViewById(R.id.root)
        favTitle = findViewById(R.id.favTitle)
        favRow = findViewById(R.id.favRow)
        allRow = findViewById(R.id.allRow)
        for (r in listOf(favRow, allRow)) {
            r.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
            r.itemAnimator = null
        }
        favRow.adapter = favAdapter
        allRow.adapter = allAdapter
        findViewById<View>(R.id.settingsBtn).setOnClickListener { showSettings() }
        theme = prefs.getInt("theme", 1)
        applyTheme()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        pendingFocus = null
        refresh()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {}

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            showSettings()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun loadList(key: String): MutableList<String> =
        (prefs.getString(key, "") ?: "").split("\n").filter { it.isNotEmpty() }.toMutableList()

    private fun saveList(key: String, l: Collection<String>) {
        prefs.edit().putString(key, l.joinToString("\n")).apply()
    }

    private fun applyTheme() {
        val c = themes[theme % themes.size]
        root.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, c)
    }

    private fun queryApps(): List<ResolveInfo> {
        val pm = packageManager
        fun query(category: String) =
            pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(category), 0)
        val seen = HashSet<String>()
        val tv = query(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val phone = query(Intent.CATEGORY_LAUNCHER)
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        return (tv + phone).filter {
            it.activityInfo.packageName != packageName && seen.add(it.activityInfo.packageName)
        }
    }

    private fun isDefaultLauncher(): Boolean {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val ri = packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
        return ri?.activityInfo?.packageName == packageName
    }

    // ---------- main refresh ----------
    private fun refresh() {
        pins = loadList("pins")
        order = loadList("order")
        hidden = loadList("hidden").toMutableSet()
        showHidden = prefs.getBoolean("showHidden", false)

        val map = LinkedHashMap<String, ResolveInfo>()
        for (ri in queryApps()) {
            val k = ri.activityInfo.packageName
            if (!map.containsKey(k)) map[k] = ri
        }
        pins = pins.filter { map.containsKey(it) }.toMutableList()
        if (pins.size > 5) pins = pins.take(5).toMutableList()

        val defaultOrder = map.keys.toList()
        val rank = HashMap<String, Int>()
        order.forEachIndexed { i, p -> rank[p] = i }
        val rest = defaultOrder
            .filter { !pins.contains(it) && (showHidden || !hidden.contains(it)) }
            .sortedBy { rank[it] ?: (10000 + defaultOrder.indexOf(it)) }
        restList = rest

        favAdapter.items = pins.map { Entry(map[it]!!, it, hidden.contains(it)) }
        allAdapter.items = rest.map { Entry(map[it]!!, it, hidden.contains(it)) }
        favAdapter.notifyDataSetChanged()
        allAdapter.notifyDataSetChanged()

        val vis = if (pins.isEmpty()) View.GONE else View.VISIBLE
        favRow.visibility = vis
        favTitle.visibility = vis

        val target = pendingFocus
        pendingFocus = null
        root.post { focusPkg(target) }
    }

    private fun focusPkg(pkg: String?) {
        val fi = favAdapter.items.indexOfFirst { it.pkg == pkg }
        val ai = allAdapter.items.indexOfFirst { it.pkg == pkg }
        val rv: RecyclerView
        val idx: Int
        when {
            fi >= 0 -> { rv = favRow; idx = fi }
            ai >= 0 -> { rv = allRow; idx = ai }
            favAdapter.items.isNotEmpty() -> { rv = favRow; idx = 0 }
            else -> { rv = allRow; idx = 0 }
        }
        rv.scrollToPosition(idx)
        rv.post { rv.findViewHolderForAdapterPosition(idx)?.itemView?.requestFocus() }
    }

    // ---------- actions ----------
    private fun launch(e: Entry) {
        val i = Intent(Intent.ACTION_MAIN)
            .setClassName(e.ri.activityInfo.packageName, e.ri.activityInfo.name)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(i) } catch (_: Exception) {}
    }

    private fun move(e: Entry, fav: Boolean, d: Int) {
        if (fav) {
            val i = pins.indexOf(e.pkg)
            val j = i + d
            if (i < 0 || j < 0 || j >= pins.size) return
            Collections.swap(pins, i, j)
            saveList("pins", pins)
        } else {
            val l = restList.toMutableList()
            val i = l.indexOf(e.pkg)
            val j = i + d
            if (i < 0 || j < 0 || j >= l.size) return
            Collections.swap(l, i, j)
            saveList("order", l + order.filter { !l.contains(it) })
        }
        pendingFocus = e.pkg
        refresh()
    }

    private fun showMenu(e: Entry, fav: Boolean) {
        val names = mutableListOf<String>()
        val acts = mutableListOf<() -> Unit>()
        fun add(n: String, a: () -> Unit) { names.add(n); acts.add(a) }

        if (fav) {
            add("Unpin from favorites") {
                pins.remove(e.pkg)
                saveList("pins", pins)
                pendingFocus = e.pkg
                refresh()
            }
        } else {
            add("Pin to favorites") {
                if (pins.size >= 5) {
                    toast("Favorites are full (5). Unpin one first.")
                } else {
                    pins.add(e.pkg)
                    saveList("pins", pins)
                    pendingFocus = e.pkg
                    refresh()
                }
            }
        }
        add("Move left") { move(e, fav, -1) }
        add("Move right") { move(e, fav, 1) }
        add(if (e.hidden) "Unhide" else "Hide") {
            if (e.hidden) hidden.remove(e.pkg) else hidden.add(e.pkg)
            pins.remove(e.pkg)
            saveList("hidden", hidden)
            saveList("pins", pins)
            refresh()
        }
        add("App info (disable / uninstall)") {
            try {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + e.pkg))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) { toast("Could not open app info") }
        }

        AlertDialog.Builder(this)
            .setTitle(e.ri.loadLabel(packageManager).toString())
            .setItems(names.toTypedArray()) { _, i -> acts[i]() }
            .show()
    }

    private fun showSettings() {
        val def = isDefaultLauncher()
        val items = arrayOf(
            if (def) "Default launcher: ON" else "Make this my default launcher",
            "Show hidden apps: " + (if (showHidden) "ON" else "OFF"),
            "Change background",
            "Reset layout (unpin, unhide, reset order)",
            "Open system settings"
        )
        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setItems(items) { _, i ->
                when (i) {
                    0 -> setDefault()
                    1 -> {
                        prefs.edit().putBoolean("showHidden", !showHidden).apply()
                        refresh()
                    }
                    2 -> {
                        theme = (theme + 1) % themes.size
                        prefs.edit().putInt("theme", theme).apply()
                        applyTheme()
                    }
                    3 -> {
                        prefs.edit().remove("pins").remove("order").remove("hidden").apply()
                        refresh()
                    }
                    4 -> try {
                        startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (_: Exception) {}
                }
            }
            .show()
    }

    private fun setDefault() {
        if (isDefaultLauncher()) {
            toast("This is already your default launcher.")
            return
        }
        val tries = listOf(
            Intent(Settings.ACTION_HOME_SETTINGS),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
            Intent(Settings.ACTION_SETTINGS)
        )
        for (i in tries) {
            try {
                startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                toast("Choose \"Home\" and tap Always.")
                return
            } catch (_: Exception) {}
        }
    }

    // ---------- adapter ----------
    inner class AppAdapter(private val tileDp: Int, private val fav: Boolean) :
        RecyclerView.Adapter<AppAdapter.VH>() {

        var items: List<Entry> = emptyList()

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val tile: View = v.findViewById(R.id.tile)
            val image: ImageView = v.findViewById(R.id.image)
            val label: TextView = v.findViewById(R.id.label)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
            val vh = VH(v)
            vh.tile.layoutParams = LinearLayout.LayoutParams(dp(tileDp), dp(tileDp * 9 / 16))
            vh.label.layoutParams =
                LinearLayout.LayoutParams(dp(tileDp), ViewGroup.LayoutParams.WRAP_CONTENT)
                    .also { it.topMargin = dp(8) }
            v.setOnFocusChangeListener { _, focused ->
                val s = if (focused) 1.12f else 1f
                v.animate().scaleX(s).scaleY(s).setDuration(120).start()
                vh.tile.animate().translationZ(if (focused) 24f else 0f).setDuration(120).start()
                vh.label.animate().alpha(if (focused) 1f else 0f).setDuration(120).start()
            }
            v.setOnClickListener {
                val p = vh.bindingAdapterPosition
                if (p != RecyclerView.NO_POSITION) launch(items[p])
            }
            v.setOnLongClickListener {
                val p = vh.bindingAdapterPosition
                if (p != RecyclerView.NO_POSITION) showMenu(items[p], fav)
                true
            }
            return vh
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val pm = packageManager
            val e = items[position]
            h.label.text = e.ri.loadLabel(pm)
            h.tile.clipToOutline = true
            h.image.alpha = if (e.hidden) 0.4f else 1f
            val banner = e.ri.activityInfo.loadBanner(pm)
            if (banner != null) {
                h.image.setPadding(0, 0, 0, 0)
                h.image.scaleType = ImageView.ScaleType.CENTER_CROP
                h.image.setImageDrawable(banner)
            } else {
                val p = dp(tileDp / 6)
                h.image.setPadding(p, p, p, p)
                h.image.scaleType = ImageView.ScaleType.FIT_CENTER
                h.image.setImageDrawable(e.ri.loadIcon(pm))
            }
        }

        override fun getItemCount() = items.size
    }
}
