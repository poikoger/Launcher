package com.me.launcher

import android.app.Activity
import android.content.Intent
import android.content.pm.ResolveInfo
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : Activity() {

    private lateinit var row: RecyclerView
    private val adapter = AppAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        row = findViewById(R.id.row)
        row.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        row.adapter = adapter
        row.itemAnimator = null
    }

    override fun onResume() {
        super.onResume()
        adapter.items = loadApps()
        adapter.notifyDataSetChanged()
        row.post { row.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() }
    }

    // Home screen: Back does nothing.
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {}

    private fun loadApps(): List<ResolveInfo> {
        val pm = packageManager
        fun query(category: String) = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(category), 0
        )
        val seen = HashSet<String>()
        val tv = query(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val phone = query(Intent.CATEGORY_LAUNCHER).sortedBy { it.loadLabel(pm).toString().lowercase() }
        return (tv + phone).filter {
            it.activityInfo.packageName != packageName && seen.add(it.activityInfo.packageName)
        }
    }

    inner class AppAdapter : RecyclerView.Adapter<AppAdapter.VH>() {
        var items: List<ResolveInfo> = emptyList()

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val tile: View = v.findViewById(R.id.tile)
            val image: ImageView = v.findViewById(R.id.image)
            val label: TextView = v.findViewById(R.id.label)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
            val vh = VH(v)
            v.setOnFocusChangeListener { _, focused ->
                val s = if (focused) 1.15f else 1f
                v.animate().scaleX(s).scaleY(s).setDuration(120).start()
                vh.tile.animate().translationZ(if (focused) 24f else 0f).setDuration(120).start()
                vh.label.animate().alpha(if (focused) 1f else 0f).setDuration(120).start()
            }
            v.setOnClickListener {
                val ri = items[vh.bindingAdapterPosition]
                val i = Intent(Intent.ACTION_MAIN)
                    .setClassName(ri.activityInfo.packageName, ri.activityInfo.name)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { startActivity(i) } catch (_: Exception) {}
            }
            return vh
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val pm = packageManager
            val ri = items[position]
            h.label.text = ri.loadLabel(pm)
            h.tile.clipToOutline = true
            val banner = ri.activityInfo.loadBanner(pm)
            if (banner != null) {
                h.image.setPadding(0, 0, 0, 0)
                h.image.scaleType = ImageView.ScaleType.CENTER_CROP
                h.image.setImageDrawable(banner)
            } else {
                val p = (28 * resources.displayMetrics.density).toInt()
                h.image.setPadding(p, p, p, p)
                h.image.scaleType = ImageView.ScaleType.FIT_CENTER
                h.image.setImageDrawable(ri.loadIcon(pm))
            }
        }

        override fun getItemCount() = items.size
    }
}
